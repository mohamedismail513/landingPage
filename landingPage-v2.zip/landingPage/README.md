# Project Name:
   **Landing Page Project**
___
## What is new in this project:
    Converting the static page into active page by adding three functions;
___
## Functions used through this project"
1. function to make the navebar dynamic.
1. function to add style change to the active section
1. function to make the tranfer between navbar link and section position smooth. 