/*creating global variable */

const sections = document.querySelectorAll('section');
const sectionNumber = sections.length;
const navBarList = document.querySelector('#navbar__list');


/*creation for document fragment */
const fragment = document.createDocumentFragment();



/*
 * Creating Functions
 * 1-Function to Add section dynamic to Nav bar (navBarCreating)
 * 2-Function to get the active section (getActiveSection)
 * 3-function to add active class (addActiveClass)
*/

function navBarCreating(){
    for(let i=0;i<sectionNumber;i++){
        const sectionName = sections[i].getAttribute('data-nav');
        const sectionLink = sections[i].getAttribute('id');
        const listElement = document.createElement('li');
        listElement.innerHTML = `<a id='link${i}'linkto = '${sectionLink}' class='menu__link' href='#${sectionLink}'>${sectionName}</a>`;
        fragment.appendChild(listElement);
    }

    navBarList.appendChild(fragment);

};


// to get the section position
function getActiveSection(section){
    let topDim = section.getBoundingClientRect().top;
    return topDim;
}


function addActiveClass(){
    for (let i=0;i<sectionNumber;i++){
        const top = getActiveSection(sections[i]);
        if (top < 150 && top >=-150){
            sections[i].classList.add('your-active-class');
            const links = document.querySelectorAll('li');
            links[i].classList.add('active-nav-link');
            
        }else{
            sections[i].classList.remove('your-active-class');
            const links = document.querySelectorAll('li');
            links[i].classList.remove('active-nav-link');
        }
    }
}




/*Calling the functions */

navBarCreating();
document.addEventListener('scroll',addActiveClass);
navBarList.addEventListener('click',(evnt)=>{
    evnt.preventDefault();
    document.getElementById(evnt.target.getAttribute('linkto')).scrollIntoView({behavior:'smooth',block:'start'});
})